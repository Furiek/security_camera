#include <Arduino.h>

SerialEmulator Serial;

